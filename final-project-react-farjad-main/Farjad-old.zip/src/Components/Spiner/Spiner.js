import { Space, Spin } from 'antd';
import React from 'react';
const Spiner = () => (
    <Space size="middle">

        <Spin size="large" />
    </Space>
);
export default Spiner;