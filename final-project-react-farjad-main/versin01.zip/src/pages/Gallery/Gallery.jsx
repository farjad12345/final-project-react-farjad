import "./Gallery.css";


function Gallery() {
 
  return (
    <section className="gallery">
      <h2>our Gallery</h2>
      <div className="container">
        <div className="lates-imgs">
          <div className="latest-img latest-img1"></div>
          <div className="latest-img latest-img2"></div>
          <div className="latest-img latest-img3"></div>
          <div className="latest-img latest-img4"></div>
          <div className="latest-img latest-img5"></div>
          <div className="latest-img latest-img6"></div>
        </div>
      </div>
    </section>
  );
}
export default Gallery;
