import "./Technology.css";


function Technology() {
 
  return (
    <section className="Technology">
      <h1 className="h1">
        تکنولوژی های استفاده شده در این پروژه
      </h1>
      
    </section>
  );
}
export default Technology;
